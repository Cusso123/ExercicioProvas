﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExercicioProva2
{
    internal class Cidade
    {
        public string nome;
        public int populacao;
    }
}
