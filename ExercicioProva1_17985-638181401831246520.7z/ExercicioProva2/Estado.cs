﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExercicioProva2
{
    internal class Estado
    {
        public void CadastrarCidade()
        {

        }
        public void ImprimirCidade()
        {

        }
        public void LocalizarCidadeMaiorPopulacao()
        {

        }
    }
}
