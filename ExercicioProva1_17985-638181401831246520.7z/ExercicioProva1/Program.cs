﻿using ExercicioProva1;

AnalisaVirus analisavirus = new AnalisaVirus();
analisavirus.AnalisarVirus();
